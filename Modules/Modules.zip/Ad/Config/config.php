<?php

return [
    'name' => 'Ad',
];
