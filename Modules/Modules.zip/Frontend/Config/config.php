<?php

return [
    'name' => 'Frontend',
];
