<?php

return [
    'name' => 'Banner',
];
